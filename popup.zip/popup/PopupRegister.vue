<template>
  <section class="detail">
    <el-form label-width="180px">

      <el-form-item label="제목" prop="subj">
        <el-input v-model="form.subj"></el-input>
      </el-form-item>

      <el-form-item label="파업구분">
          <el-select v-model="form.popupTp">
            <el-option
              v-for="item in tpOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
      </el-form-item>

      <el-form-item label="대체텍스트">
        <el-input v-model="form.subConts"></el-input>
      </el-form-item>

      <el-form-item label="바로가기">
        <el-radio-group v-model="form.cnntUrlYn">
          <el-radio label="사용"></el-radio>
          <el-radio label="미사용"></el-radio>
        </el-radio-group>
        <el-input v-model="form.cnntUrl" placeholder="팝업 이미지 클릭시 이동할 URL을 입력하세요.">
        </el-input>
      </el-form-item>

      <el-form-item label="이미지등록">
        <el-upload
          class="upload-demo"
          action=""
          name="file"
          :multiple="false"
          :on-remove="onImgRemove"
          :on-change="onImgChange"
          :auto-upload="false"
          :limit="1"
          :file-list="fileList"
          list-type="picture">
          <el-button size="small" type="info">파일업로드</el-button>
          <div slot="tip" class="ex-1">※ JPG,PNG 파일만 업로드 가능합니다. 해상도는 400 X 600에 최적화 되어있습니다.</div>
        </el-upload>
      </el-form-item>

    </el-form>

    <div class="bottomBtns">
      <el-button v-if="!modifyYn" type="primary" @click="onSubmit('form')">등록</el-button>
      <el-button v-if="modifyYn" type="primary" @click="onUpdate('form')">수정</el-button>
      <el-button type="primary" @click="onCancel">취소</el-button>
    </div>
    
  </section>
</template>
<script>
  export default {
    
    data() {
      return {
       
        form: {
          subj: '',
          popupTp: '기본',
          subConts: '',
          cnntUrlYn: '',
          cnntUrl: ''
        },
        
        fileList: [],
        modifyYn: false,

        tpOptions: [{
          value: '기본',
          label: '기본'
        }, {
          value: '이용동의',
          label: '이용동의'
        }, {
          value: '이벤트',
          label: '이벤트'
        }]
      }
    },
    
    methods: {
   
      onSubmit() {
       
      },
    
      // 글 수정
      onUpdate() {
        
      },

      // 글 등록 취소
      onCancel() {
        
      },

      // 이미지 삭제
      onImgRemove(file, fileList) {

      },

      // 이미지 변환
      onImgChange(file, fileList) {

      }
    }
    
  }
</script>
<style scoped>
  .ex-1 {
    color: red
  }
 
</style>

